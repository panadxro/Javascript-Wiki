const logger = require('./logger')

// logger.log("Mensaje por consola")
logger.info("Mensaje informativo");
logger.debug("Mensaje debug")
logger.warn("Mensaje de advertencia");
logger.error("Mensaje de error");
