// Modulos externos funciones matematicas
// Export ES6 

export function suma(a, b) {
    return a + b;
}

export function multiplica(a, b) {
    return a * b;
}