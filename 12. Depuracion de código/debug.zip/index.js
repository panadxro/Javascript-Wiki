const persona = {
  nombre: "Lucas",
  edad: "22"
}
console.log(persona)

function obtenDobleEdad(edad) {
  return 2 * edad
}

const dobleEdad = obtenDobleEdad(persona.edad)

console.log(dobleEdad)