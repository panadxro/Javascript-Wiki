// Altura (cm)
let alturacm = 181;

// Altura (m)
let alturam = 1.81;

// Peso (Kg)
let pesokg = 71.3;

// AlturaM redondeado
let altM = alturam.toFixed();
console.log(altM);

// PesoK redondeado
let pesK = pesokg.toFixed();
console.log(pesK);

// MAX_VALOR
let maxValor = 'el máximo valor que se puede obtener en Javascript + 1 ' + Number.MAX_VALUE;
console.log(maxValor);