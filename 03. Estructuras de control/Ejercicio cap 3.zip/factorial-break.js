 //factorial de 10 
 //while, if & break

const listado = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13];
let z = 0

while (z < listado.length) {
  console.log(z);
  z++;
  if (z > 10) {
    break
  }
}
